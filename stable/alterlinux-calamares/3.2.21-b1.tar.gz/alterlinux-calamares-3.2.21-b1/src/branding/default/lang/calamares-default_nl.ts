<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="nl">
<context>
    <name>show</name>
    <message>
        <location filename="../show.qml" line="64"/>
        <source>This is a second Slide element.</source>
        <translation>Dit is het tweede Dia element.</translation>
    </message>
    <message>
        <location filename="../show.qml" line="68"/>
        <source>This is a third Slide element.</source>
        <translation>Dit is het derde Dia element.</translation>
    </message>
</context>
</TS>
